import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Navbar = () => {
  const { user, logout } = useAuth();

  return (
    <nav className="navbar">
      <Link to="/dashboard" className="navbar-brand">
        Grant Program Management
      </Link>
      
      <div className="navbar-nav">
        {user ? (
          <>
            <span style={{ fontSize: '0.875rem', color: '#9CA3AF' }}>
              {user.name} ({user.role})
            </span>
            <button onClick={logout} className="btn btn-outline" style={{ color: 'white', borderColor: 'white' }}>
              Logout
            </button>
          </>
        ) : (
          <>
            <Link to="/login" className="nav-link">Login</Link>
            <Link to="/register" className="nav-link">Register</Link>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
