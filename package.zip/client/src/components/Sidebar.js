import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Sidebar = () => {
  const { user } = useAuth();

  const adminLinks = [
    { path: '/dashboard', label: 'Dashboard', icon: '📊' },
    { path: '/applications', label: 'Applications', icon: '📝' },
    { path: '/grant-cycles', label: 'Grant Cycles', icon: '📅' },
    { path: '/admin', label: 'User Management', icon: '👥' },
    { path: '/analytics', label: 'Analytics', icon: '📈' },
  ];

  const reviewerLinks = [
    { path: '/dashboard', label: 'Dashboard', icon: '📊' },
    { path: '/review', label: 'Review Applications', icon: '✅' },
    { path: '/grant-cycles', label: 'Grant Cycles', icon: '📅' },
  ];

  const applicantLinks = [
    { path: '/dashboard', label: 'Dashboard', icon: '📊' },
    { path: '/applications', label: 'My Applications', icon: '📝' },
    { path: '/grant-cycles', label: 'Grant Cycles', icon: '📅' },
  ];

  const links = user?.role === 'admin' 
    ? adminLinks 
    : user?.role === 'reviewer' 
      ? reviewerLinks 
      : applicantLinks;

  return (
    <aside className="sidebar">
      <ul className="sidebar-nav">
        {links.map((link) => (
          <li key={link.path} className="sidebar-item">
            <NavLink 
              to={link.path} 
              className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
            >
              <span>{link.icon}</span>
              {link.label}
            </NavLink>
          </li>
        ))}
      </ul>
    </aside>
  );
};

export default Sidebar;
