import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import LoadingSpinner from '../components/LoadingSpinner';

const Dashboard = () => {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const response = await axios.get('/api/analytics/dashboard');
      setData(response.data.data);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  const renderAdminDashboard = () => (
    <>
      <div className="grid grid-cols-4 mt-6">
        <div className="stat-card">
          <div className="stat-value">{data?.activeCycles || 0}</div>
          <div className="stat-label">Active Cycles</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{data?.pendingReviews || 0}</div>
          <div className="stat-label">Pending Reviews</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{data?.recentApplications?.length || 0}</div>
          <div className="stat-label">Recent Applications</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{user?.role}</div>
          <div className="stat-label">Your Role</div>
        </div>
      </div>

      <div className="card mt-6">
        <div className="card-header">
          <h2 className="card-title">Recent Applications</h2>
          <Link to="/applications" className="btn btn-outline btn-sm">
            View All
          </Link>
        </div>
        
        {data?.recentApplications?.length > 0 ? (
          <div className="table-container">
            <table className="table">
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Applicant</th>
                  <th>Grant Cycle</th>
                  <th>Status</th>
                  <th>Score</th>
                </tr>
              </thead>
              <tbody>
                {data.recentApplications.map((app) => (
                  <tr key={app._id}>
                    <td>
                      <Link to={`/applications/${app._id}`} style={{ color: 'var(--accent-color)' }}>
                        {app.title}
                      </Link>
                    </td>
                    <td>{app.applicant?.name}</td>
                    <td>{app.grantCycle?.name}</td>
                    <td>
                      <span className={`badge badge-${app.status === 'approved' ? 'success' : app.status === 'rejected' ? 'danger' : 'warning'}`}>
                        {app.status}
                      </span>
                    </td>
                    <td>{app.averageScore?.toFixed(1) || 'N/A'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-center" style={{ padding: '2rem', color: 'var(--text-secondary)' }}>
            No applications yet
          </p>
        )}
      </div>
    </>
  );

  const renderReviewerDashboard = () => (
    <>
      <div className="grid grid-cols-3 mt-6">
        <div className="stat-card">
          <div className="stat-value">{data?.pendingReviews || 0}</div>
          <div className="stat-label">Pending Reviews</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{data?.completedReviews || 0}</div>
          <div className="stat-label">Completed Reviews</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{data?.assignedApplications?.length || 0}</div>
          <div className="stat-label">Assigned Applications</div>
        </div>
      </div>

      <div className="card mt-6">
        <div className="card-header">
          <h2 className="card-title">Applications to Review</h2>
          <Link to="/review" className="btn btn-primary btn-sm">
            Go to Review Panel
          </Link>
        </div>
        
        {data?.assignedApplications?.length > 0 ? (
          <div className="table-container">
            <table className="table">
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Applicant</th>
                  <th>Organization</th>
                  <th>Grant Cycle</th>
                  <th>Budget</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {data.assignedApplications.map((app) => (
                  <tr key={app._id}>
                    <td>{app.title}</td>
                    <td>{app.applicant?.name}</td>
                    <td>{app.applicant?.organization || 'N/A'}</td>
                    <td>{app.grantCycle?.name}</td>
                    <td>${app.budgetRequested?.toLocaleString()}</td>
                    <td>
                      <Link to={`/applications/${app._id}`} className="btn btn-outline btn-sm">
                        Review
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-center" style={{ padding: '2rem', color: 'var(--text-secondary)' }}>
            No applications assigned for review
          </p>
        )}
      </div>
    </>
  );

  const renderApplicantDashboard = () => (
    <>
      <div className="flex justify-between items-center mt-6">
        <h2>My Applications</h2>
        <Link to="/applications/new" className="btn btn-primary">
          New Application
        </Link>
      </div>

      {data?.myApplications?.length > 0 ? (
        <div className="grid grid-cols-2 mt-4">
          {data.myApplications.map((app) => (
            <div key={app._id} className="card">
              <div className="flex justify-between items-center">
                <h3 style={{ fontSize: '1rem', fontWeight: 600 }}>{app.title}</h3>
                <span className={`badge badge-${app.status === 'approved' ? 'success' : app.status === 'rejected' ? 'danger' : app.status === 'submitted' ? 'info' : 'warning'}`}>
                  {app.status}
                </span>
              </div>
              <p style={{ marginTop: '0.5rem', color: 'var(--text-secondary)', fontSize: '0.875rem' }}>
                {app.grantCycle?.name}
              </p>
              <p style={{ marginTop: '0.25rem', fontSize: '0.875rem' }}>
                Budget: ${app.budgetRequested?.toLocaleString()}
              </p>
              <Link to={`/applications/${app._id}`} className="btn btn-outline mt-3" style={{ width: '100%' }}>
                View Details
              </Link>
            </div>
          ))}
        </div>
      ) : (
        <div className="card mt-4 text-center">
          <p style={{ color: 'var(--text-secondary)', marginBottom: '1rem' }}>
            You haven't submitted any applications yet
          </p>
          <Link to="/grant-cycles" className="btn btn-primary">
            Browse Grant Cycles
          </Link>
        </div>
      )}
    </>
  );

  return (
    <div>
      <h1 style={{ fontSize: '1.5rem', fontWeight: 700 }}>
        Welcome back, {user?.name}!
      </h1>
      <p style={{ color: 'var(--text-secondary)', marginTop: '0.5rem' }}>
        Here's what's happening with your grant program
      </p>

      {user?.role === 'admin' && renderAdminDashboard()}
      {user?.role === 'reviewer' && renderReviewerDashboard()}
      {user?.role === 'applicant' && renderApplicantDashboard()}
    </div>
  );
};

export default Dashboard;
