import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';
import LoadingSpinner from '../components/LoadingSpinner';

const ApplicationForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(!!id);
  const [grantCycles, setGrantCycles] = useState([]);
  
  const [formData, setFormData] = useState({
    grantCycle: '',
    title: '',
    summary: '',
    fullProposal: '',
    budgetRequested: '',
    budgetBreakdown: {
      personnel: '',
      equipment: '',
      services: '',
      other: '',
      description: ''
    },
    timeline: '',
    teamMembers: [{ name: '', role: '', experience: '' }]
  });

  useEffect(() => {
    fetchGrantCycles();
    if (id) {
      fetchApplication();
    }
  }, [id]);

  const fetchGrantCycles = async () => {
    try {
      const response = await axios.get('/api/grant-cycles?status=active');
      setGrantCycles(response.data.data);
    } catch (error) {
      console.error('Error fetching grant cycles:', error);
    }
  };

  const fetchApplication = async () => {
    try {
      const response = await axios.get(`/api/applications/${id}`);
      const app = response.data.data;
      setFormData({
        grantCycle: app.grantCycle?._id || '',
        title: app.title || '',
        summary: app.summary || '',
        fullProposal: app.fullProposal || '',
        budgetRequested: app.budgetRequested || '',
        budgetBreakdown: app.budgetBreakdown || {
          personnel: '',
          equipment: '',
          services: '',
          other: '',
          description: ''
        },
        timeline: app.timeline || '',
        teamMembers: app.teamMembers || [{ name: '', role: '', experience: '' }]
      });
    } catch (error) {
      console.error('Error fetching application:', error);
      toast.error('Failed to load application');
      navigate('/applications');
    } finally {
      setInitialLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name.startsWith('breakdown.')) {
      const field = name.split('.')[1];
      setFormData({
        ...formData,
        budgetBreakdown: {
          ...formData.budgetBreakdown,
          [field]: value
        }
      });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleTeamMemberChange = (index, field, value) => {
    const updatedMembers = [...formData.teamMembers];
    updatedMembers[index][field] = value;
    setFormData({ ...formData, teamMembers: updatedMembers });
  };

  const addTeamMember = () => {
    setFormData({
      ...formData,
      teamMembers: [...formData.teamMembers, { name: '', role: '', experience: '' }]
    });
  };

  const removeTeamMember = (index) => {
    const updatedMembers = formData.teamMembers.filter((_, i) => i !== index);
    setFormData({ ...formData, teamMembers: updatedMembers });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const payload = {
        ...formData,
        budgetRequested: parseFloat(formData.budgetRequested),
        budgetBreakdown: {
          personnel: parseFloat(formData.budgetBreakdown.personnel) || 0,
          equipment: parseFloat(formData.budgetBreakdown.equipment) || 0,
          services: parseFloat(formData.budgetBreakdown.services) || 0,
          other: parseFloat(formData.budgetBreakdown.other) || 0,
          description: formData.budgetBreakdown.description
        }
      };

      if (id) {
        await axios.put(`/api/applications/${id}`, payload);
        toast.success('Application updated successfully!');
      } else {
        await axios.post('/api/applications', payload);
        toast.success('Application created successfully!');
      }
      
      navigate('/applications');
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to save application');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitAction = async (submit = false) => {
    if (submit) {
      try {
        await axios.post(`/api/applications/${id}/submit`);
        toast.success('Application submitted successfully!');
        navigate('/applications');
      } catch (error) {
        toast.error(error.response?.data?.message || 'Failed to submit application');
      }
    }
  };

  if (initialLoading) {
    return <LoadingSpinner />;
  }

  return (
    <div>
      <h1 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: '1.5rem' }}>
        {id ? 'Edit Application' : 'New Application'}
      </h1>

      <form onSubmit={handleSubmit}>
        <div className="card">
          <h2 className="card-title mb-4">Basic Information</h2>
          
          {!id && (
            <div className="form-group">
              <label className="form-label">Grant Cycle *</label>
              <select
                name="grantCycle"
                className="form-select"
                value={formData.grantCycle}
                onChange={handleChange}
                required
              >
                <option value="">Select a grant cycle</option>
                {grantCycles.map((cycle) => (
                  <option key={cycle._id} value={cycle._id}>
                    {cycle.name} (${cycle.minGrantAmount} - ${cycle.maxGrantAmount})
                  </option>
                ))}
              </select>
            </div>
          )}

          <div className="form-group">
            <label className="form-label">Project Title *</label>
            <input
              type="text"
              name="title"
              className="form-input"
              value={formData.title}
              onChange={handleChange}
              required
              maxLength={200}
              placeholder="Enter your project title"
            />
          </div>

          <div className="form-group">
            <label className="form-label">Project Summary *</label>
            <textarea
              name="summary"
              className="form-textarea"
              value={formData.summary}
              onChange={handleChange}
              required
              maxLength={500}
              placeholder="Brief summary of your project (max 500 characters)"
              rows={3}
            />
          </div>

          <div className="form-group">
            <label className="form-label">Full Proposal *</label>
            <textarea
              name="fullProposal"
              className="form-textarea"
              value={formData.fullProposal}
              onChange={handleChange}
              required
              placeholder="Detailed description of your project"
              rows={10}
              style={{ minHeight: '200px' }}
            />
          </div>
        </div>

        <div className="card">
          <h2 className="card-title mb-4">Budget</h2>
          
          <div className="form-group">
            <label className="form-label">Total Budget Requested (USD) *</label>
            <input
              type="number"
              name="budgetRequested"
              className="form-input"
              value={formData.budgetRequested}
              onChange={handleChange}
              required
              min="1"
              placeholder="Enter the total amount requested"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="form-group">
              <label className="form-label">Personnel</label>
              <input
                type="number"
                name="breakdown.personnel"
                className="form-input"
                value={formData.budgetBreakdown.personnel}
                onChange={handleChange}
                min="0"
                placeholder="Personnel costs"
              />
            </div>
            <div className="form-group">
              <label className="form-label">Equipment</label>
              <input
                type="number"
                name="breakdown.equipment"
                className="form-input"
                value={formData.budgetBreakdown.equipment}
                onChange={handleChange}
                min="0"
                placeholder="Equipment costs"
              />
            </div>
            <div className="form-group">
              <label className="form-label">Services</label>
              <input
                type="number"
                name="breakdown.services"
                className="form-input"
                value={formData.budgetBreakdown.services}
                onChange={handleChange}
                min="0"
                placeholder="Service costs"
              />
            </div>
            <div className="form-group">
              <label className="form-label">Other</label>
              <input
                type="number"
                name="breakdown.other"
                className="form-input"
                value={formData.budgetBreakdown.other}
                onChange={handleChange}
                min="0"
                placeholder="Other costs"
              />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Budget Description</label>
            <textarea
              name="breakdown.description"
              className="form-textarea"
              value={formData.budgetBreakdown.description}
              onChange={handleChange}
              placeholder="Explain how the budget will be used"
              rows={3}
            />
          </div>
        </div>

        <div className="card">
          <h2 className="card-title mb-4">Timeline & Team</h2>
          
          <div className="form-group">
            <label className="form-label">Project Timeline</label>
            <textarea
              name="timeline"
              className="form-textarea"
              value={formData.timeline}
              onChange={handleChange}
              placeholder="Describe your project timeline and milestones"
              rows={4}
            />
          </div>

          <div className="form-group">
            <label className="form-label">Team Members</label>
            {formData.teamMembers.map((member, index) => (
              <div key={index} className="flex gap-2 mb-2">
                <input
                  type="text"
                  className="form-input"
                  value={member.name}
                  onChange={(e) => handleTeamMemberChange(index, 'name', e.target.value)}
                  placeholder="Name"
                />
                <input
                  type="text"
                  className="form-input"
                  value={member.role}
                  onChange={(e) => handleTeamMemberChange(index, 'role', e.target.value)}
                  placeholder="Role"
                />
                <input
                  type="text"
                  className="form-input"
                  value={member.experience}
                  onChange={(e) => handleTeamMemberChange(index, 'experience', e.target.value)}
                  placeholder="Experience"
                />
                {formData.teamMembers.length > 1 && (
                  <button
                    type="button"
                    className="btn btn-danger btn-sm"
                    onClick={() => removeTeamMember(index)}
                  >
                    X
                  </button>
                )}
              </div>
            ))}
            <button
              type="button"
              className="btn btn-outline btn-sm mt-2"
              onClick={addTeamMember}
            >
              + Add Team Member
            </button>
          </div>
        </div>

        <div className="flex justify-between">
          <button
            type="button"
            className="btn btn-outline"
            onClick={() => navigate('/applications')}
          >
            Cancel
          </button>
          <div className="flex gap-2">
            <button
              type="submit"
              className="btn btn-secondary"
              disabled={loading}
            >
              {loading ? 'Saving...' : 'Save as Draft'}
            </button>
            {id && formData.status === 'draft' && (
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => handleSubmitAction(true)}
              >
                Submit Application
              </button>
            )}
          </div>
        </div>
      </form>
    </div>
  );
};

export default ApplicationForm;
