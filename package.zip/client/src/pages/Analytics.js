import React, { useState, useEffect } from 'react';
import axios from 'axios';
import LoadingSpinner from '../components/LoadingSpinner';

const Analytics = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const fetchAnalytics = async () => {
    try {
      const response = await axios.get('/api/analytics/summary');
      setData(response.data.data);
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div>
      <h1 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: '1.5rem' }}>
        Analytics Dashboard
      </h1>

      {/* Overview Stats */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="stat-card">
          <div className="stat-value">{data?.applications?.total || 0}</div>
          <div className="stat-label">Total Applications</div>
        </div>
        <div className="stat-card">
          <div className="stat-value" style={{ color: 'var(--success-color)' }}>
            {data?.applications?.approvalRate || 0}%
          </div>
          <div className="stat-label">Approval Rate</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">
            ${(data?.budget?.totalBudgetApproved || 0).toLocaleString()}
          </div>
          <div className="stat-label">Total Budget Approved</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">
            {data?.reviews?.totalReviews || 0}
          </div>
          <div className="stat-label">Total Reviews</div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6">
        {/* Applications by Status */}
        <div className="card">
          <h2 className="card-title mb-4">Applications by Status</h2>
          {data?.byStatus?.length > 0 ? (
            <div className="table-container">
              <table className="table">
                <thead>
                  <tr>
                    <th>Status</th>
                    <th>Count</th>
                    <th>Percentage</th>
                  </tr>
                </thead>
                <tbody>
                  {data.byStatus.map((item) => (
                    <tr key={item._id}>
                      <td style={{ textTransform: 'capitalize' }}>{item._id?.replace('_', ' ')}</td>
                      <td>{item.count}</td>
                      <td>
                        {((item.count / data.applications.total) * 100).toFixed(1)}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p style={{ color: 'var(--text-secondary)' }}>No data available</p>
          )}
        </div>

        {/* Score Analysis */}
        <div className="card">
          <h2 className="card-title mb-4">Average Scores</h2>
          {data?.scores && Object.keys(data.scores).length > 0 ? (
            <div>
              {Object.entries(data.scores).filter(([key]) => key !== '_id').map(([key, value]) => (
                <div key={key} className="flex justify-between items-center mb-3" style={{ padding: '0.75rem', backgroundColor: 'var(--background)', borderRadius: 'var(--radius)' }}>
                  <span style={{ textTransform: 'capitalize' }}>{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                  <span style={{ fontWeight: 600 }}>{value?.toFixed(1) || 'N/A'}</span>
                </div>
              ))}
            </div>
          ) : (
            <p style={{ color: 'var(--text-secondary)' }}>No score data available</p>
          )}
        </div>

        {/* Budget Analysis */}
        <div className="card">
          <h2 className="card-title mb-4">Budget Analysis</h2>
          {data?.budget && data.budget.totalBudgetApproved > 0 ? (
            <div>
              <div className="mb-3">
                <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Average Budget Approved</div>
                <div style={{ fontSize: '1.25rem', fontWeight: 600 }}>
                  ${data.budget.avgBudgetApproved?.toLocaleString() || 0}
                </div>
              </div>
              <div className="mb-3">
                <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Maximum Budget Approved</div>
                <div style={{ fontSize: '1.25rem', fontWeight: 600 }}>
                  ${data.budget.maxBudgetApproved?.toLocaleString() || 0}
                </div>
              </div>
              <div className="mb-3">
                <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Minimum Budget Approved</div>
                <div style={{ fontSize: '1.25rem', fontWeight: 600 }}>
                  ${data.budget.minBudgetApproved?.toLocaleString() || 0}
                </div>
              </div>
            </div>
          ) : (
            <p style={{ color: 'var(--text-secondary)' }}>No budget data available</p>
          )}
        </div>

        {/* Performance by Grant Cycle */}
        <div className="card">
          <h2 className="card-title mb-4">Performance by Grant Cycle</h2>
          {data?.byCycle?.length > 0 ? (
            <div className="table-container">
              <table className="table">
                <thead>
                  <tr>
                    <th>Cycle</th>
                    <th>Total</th>
                    <th>Approved</th>
                    <th>Approval Rate</th>
                  </tr>
                </thead>
                <tbody>
                  {data.byCycle.map((cycle, index) => (
                    <tr key={index}>
                      <td>{cycle.cycleName}</td>
                      <td>{cycle.total}</td>
                      <td>{cycle.approved}</td>
                      <td>{cycle.approvalRate?.toFixed(1) || 0}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p style={{ color: 'var(--text-secondary)' }}>No cycle data available</p>
          )}
        </div>
      </div>

      {/* Export Button */}
      <div className="mt-6">
        <a href="/api/analytics/export" className="btn btn-primary">
          Export Data (CSV)
        </a>
      </div>
    </div>
  );
};

export default Analytics;
