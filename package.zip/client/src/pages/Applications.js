import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import LoadingSpinner from '../components/LoadingSpinner';

const Applications = () => {
  const { user } = useAuth();
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState({ status: '', grantCycle: '' });

  useEffect(() => {
    fetchApplications();
  }, [filter]);

  const fetchApplications = async () => {
    try {
      const params = new URLSearchParams();
      if (filter.status) params.append('status', filter.status);
      if (filter.grantCycle) params.append('grantCycle', filter.grantCycle);
      
      const response = await axios.get(`/api/applications?${params}`);
      setApplications(response.data.data);
    } catch (error) {
      console.error('Error fetching applications:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    const statusMap = {
      draft: 'warning',
      submitted: 'info',
      under_review: 'info',
      approved: 'success',
      rejected: 'danger',
      revision_requested: 'warning'
    };
    return statusMap[status] || 'warning';
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 style={{ fontSize: '1.5rem', fontWeight: 700 }}>Applications</h1>
        {user?.role === 'applicant' && (
          <Link to="/applications/new" className="btn btn-primary">
            New Application
          </Link>
        )}
      </div>

      <div className="card">
        <div className="flex gap-4 mb-4">
          <select 
            className="form-select" 
            style={{ width: '200px' }}
            value={filter.status}
            onChange={(e) => setFilter({ ...filter, status: e.target.value })}
          >
            <option value="">All Statuses</option>
            <option value="draft">Draft</option>
            <option value="submitted">Submitted</option>
            <option value="under_review">Under Review</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
          </select>
        </div>

        {applications.length > 0 ? (
          <div className="table-container">
            <table className="table">
              <thead>
                <tr>
                  <th>Title</th>
                  {user?.role !== 'applicant' && <th>Applicant</th>}
                  <th>Grant Cycle</th>
                  <th>Budget</th>
                  <th>Status</th>
                  <th>Score</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {applications.map((app) => (
                  <tr key={app._id}>
                    <td style={{ fontWeight: 500 }}>{app.title}</td>
                    {user?.role !== 'applicant' && (
                      <td>
                        <div>{app.applicant?.name}</div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                          {app.applicant?.email}
                        </div>
                      </td>
                    )}
                    <td>{app.grantCycle?.name}</td>
                    <td>${app.budgetRequested?.toLocaleString()}</td>
                    <td>
                      <span className={`badge badge-${getStatusBadge(app.status)}`}>
                        {app.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td>{app.averageScore?.toFixed(1) || 'N/A'}</td>
                    <td>
                      <Link to={`/applications/${app._id}`} className="btn btn-outline btn-sm">
                        View
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center" style={{ padding: '3rem', color: 'var(--text-secondary)' }}>
            <p>No applications found</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Applications;
