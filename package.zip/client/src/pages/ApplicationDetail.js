import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import LoadingSpinner from '../components/LoadingSpinner';

const ApplicationDetail = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const [application, setApplication] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchApplication();
  }, [id]);

  const fetchApplication = async () => {
    try {
      const response = await axios.get(`/api/applications/${id}`);
      setApplication(response.data.data);
    } catch (error) {
      console.error('Error fetching application:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    const statusMap = {
      draft: 'warning',
      submitted: 'info',
      under_review: 'info',
      approved: 'success',
      rejected: 'danger',
      revision_requested: 'warning'
    };
    return statusMap[status] || 'warning';
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  if (!application) {
    return (
      <div className="text-center" style={{ padding: '3rem' }}>
        <p>Application not found</p>
        <Link to="/applications" className="btn btn-primary mt-4">
          Back to Applications
        </Link>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <Link to="/applications" style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>
            &larr; Back to Applications
          </Link>
          <h1 style={{ fontSize: '1.5rem', fontWeight: 700, marginTop: '0.5rem' }}>
            {application.title}
          </h1>
        </div>
        <span className={`badge badge-${getStatusBadge(application.status)}`} style={{ fontSize: '0.875rem', padding: '0.5rem 1rem' }}>
          {application.status.replace('_', ' ').toUpperCase()}
        </span>
      </div>

      <div className="grid grid-cols-3 gap-6">
        <div style={{ gridColumn: 'span 2' }}>
          <div className="card">
            <h2 className="card-title mb-4">Project Details</h2>
            
            <div className="form-group">
              <label className="form-label">Summary</label>
              <p>{application.summary}</p>
            </div>

            <div className="form-group">
              <label className="form-label">Full Proposal</label>
              <div style={{ whiteSpace: 'pre-wrap', backgroundColor: 'var(--background)', padding: '1rem', borderRadius: 'var(--radius)' }}>
                {application.fullProposal}
              </div>
            </div>

            {application.timeline && (
              <div className="form-group">
                <label className="form-label">Timeline</label>
                <p>{application.timeline}</p>
              </div>
            )}
          </div>

          {application.teamMembers?.length > 0 && (
            <div className="card mt-6">
              <h2 className="card-title mb-4">Team Members</h2>
              <div className="grid grid-cols-2 gap-4">
                {application.teamMembers.map((member, index) => (
                  <div key={index} style={{ padding: '1rem', backgroundColor: 'var(--background)', borderRadius: 'var(--radius)' }}>
                    <div style={{ fontWeight: 600 }}>{member.name}</div>
                    <div style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>{member.role}</div>
                    <div style={{ fontSize: '0.875rem', marginTop: '0.5rem' }}>{member.experience}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div>
          <div className="card">
            <h2 className="card-title mb-4">Application Info</h2>
            
            <div className="mb-4">
              <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '0.25rem' }}>Grant Cycle</div>
              <div style={{ fontWeight: 500 }}>{application.grantCycle?.name}</div>
            </div>

            <div className="mb-4">
              <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '0.25rem' }}>Budget Requested</div>
              <div style={{ fontWeight: 500, fontSize: '1.25rem' }}>${application.budgetRequested?.toLocaleString()}</div>
            </div>

            {application.averageScore > 0 && (
              <div className="mb-4">
                <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '0.25rem' }}>Average Score</div>
                <div style={{ fontWeight: 500, fontSize: '1.25rem' }}>{application.averageScore?.toFixed(1)} / 10</div>
              </div>
            )}

            {application.submittedAt && (
              <div className="mb-4">
                <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '0.25rem' }}>Submitted</div>
                <div style={{ fontWeight: 500 }}>{new Date(application.submittedAt).toLocaleDateString()}</div>
              </div>
            )}
          </div>

          {(user?.role === 'admin' || user?.role === 'reviewer') && (
            <div className="card mt-4">
              <h2 className="card-title mb-4">Applicant Info</h2>
              
              <div className="mb-3">
                <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '0.25rem' }}>Name</div>
                <div style={{ fontWeight: 500 }}>{application.applicant?.name}</div>
              </div>
              
              <div className="mb-3">
                <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '0.25rem' }}>Email</div>
                <div style={{ fontWeight: 500 }}>{application.applicant?.email}</div>
              </div>
              
              {application.applicant?.organization && (
                <div className="mb-3">
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '0.25rem' }}>Organization</div>
                  <div style={{ fontWeight: 500 }}>{application.applicant.organization}</div>
                </div>
              )}
            </div>
          )}

          {user?.role === 'applicant' && application.status === 'draft' && (
            <div className="mt-4">
              <Link to={`/applications/${id}/edit`} className="btn btn-primary" style={{ width: '100%' }}>
                Edit Application
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ApplicationDetail;
