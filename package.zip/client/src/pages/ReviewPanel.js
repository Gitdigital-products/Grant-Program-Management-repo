import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import LoadingSpinner from '../components/LoadingSpinner';

const ReviewPanel = () => {
  const [applications, setApplications] = useState([]);
  const [completedReviews, setCompletedReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('pending');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [pendingRes, reviewsRes] = await Promise.all([
        axios.get('/api/reviews/pending'),
        axios.get('/api/reviews')
      ]);
      setApplications(pendingRes.data.data);
      setCompletedReviews(reviewsRes.data.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div>
      <h1 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: '1.5rem' }}>
        Review Panel
      </h1>

      <div className="flex gap-2 mb-6">
        <button
          className={`btn ${activeTab === 'pending' ? 'btn-primary' : 'btn-outline'}`}
          onClick={() => setActiveTab('pending')}
        >
          Pending Reviews ({applications.length})
        </button>
        <button
          className={`btn ${activeTab === 'completed' ? 'btn-primary' : 'btn-outline'}`}
          onClick={() => setActiveTab('completed')}
        >
          Completed Reviews ({completedReviews.length})
        </button>
      </div>

      {activeTab === 'pending' && (
        <>
          {applications.length > 0 ? (
            <div className="grid grid-cols-2 gap-6">
              {applications.map((app) => (
                <div key={app._id} className="card">
                  <div className="flex justify-between items-start mb-3">
                    <h2 style={{ fontSize: '1rem', fontWeight: 600 }}>{app.title}</h2>
                    <span className="badge badge-warning">Pending</span>
                  </div>
                  
                  <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', marginBottom: '1rem' }}>
                    {app.summary}
                  </p>

                  <div className="flex justify-between items-center mb-4" style={{ fontSize: '0.875rem' }}>
                    <div>
                      <span style={{ color: 'var(--text-secondary)' }}>Applicant: </span>
                      <span>{app.applicant?.name}</span>
                    </div>
                    <div>
                      <span style={{ color: 'var(--text-secondary)' }}>Budget: </span>
                      <span>${app.budgetRequested?.toLocaleString()}</span>
                    </div>
                  </div>

                  <Link to={`/applications/${app._id}`} className="btn btn-primary" style={{ width: '100%' }}>
                    Start Review
                  </Link>
                </div>
              ))}
            </div>
          ) : (
            <div className="card text-center" style={{ padding: '3rem' }}>
              <p style={{ color: 'var(--text-secondary)' }}>No pending reviews</p>
            </div>
          )}
        </>
      )}

      {activeTab === 'completed' && (
        <>
          {completedReviews.length > 0 ? (
            <div className="card">
              <div className="table-container">
                <table className="table">
                  <thead>
                    <tr>
                      <th>Application</th>
                      <th>Your Score</th>
                      <th>Recommendation</th>
                      <th>Submitted</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {completedReviews.map((review) => (
                      <tr key={review._id}>
                        <td>{review.application?.title}</td>
                        <td>{review.totalScore}</td>
                        <td>
                          <span className={`badge badge-${review.recommendation?.includes('approve') ? 'success' : 'danger'}`}>
                            {review.recommendation?.replace('_', ' ')}
                          </span>
                        </td>
                        <td>{new Date(review.submittedAt).toLocaleDateString()}</td>
                        <td>
                          <Link to={`/applications/${review.application?._id}`} className="btn btn-outline btn-sm">
                            View
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div className="card text-center" style={{ padding: '3rem' }}>
              <p style={{ color: 'var(--text-secondary)' }}>No completed reviews yet</p>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default ReviewPanel;
