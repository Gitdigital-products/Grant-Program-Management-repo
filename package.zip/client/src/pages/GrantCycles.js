import React, { useState, useEffect } from 'react';
import axios from 'axios';
import LoadingSpinner from '../components/LoadingSpinner';

const GrantCycles = () => {
  const [cycles, setCycles] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCycles();
  }, []);

  const fetchCycles = async () => {
    try {
      const response = await axios.get('/api/grant-cycles');
      setCycles(response.data.data);
    } catch (error) {
      console.error('Error fetching grant cycles:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    const statusMap = {
      draft: 'warning',
      active: 'success',
      reviewing: 'info',
      closed: 'danger',
      completed: 'info'
    };
    return statusMap[status] || 'warning';
  };

  const isAcceptingApplications = (cycle) => {
    const now = new Date();
    return cycle.status === 'active' && 
           new Date(cycle.applicationDeadline) > now;
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div>
      <h1 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: '1.5rem' }}>
        Grant Cycles
      </h1>

      {cycles.length > 0 ? (
        <div className="grid grid-cols-2 gap-6">
          {cycles.map((cycle) => (
            <div key={cycle._id} className="card">
              <div className="flex justify-between items-start mb-3">
                <h2 style={{ fontSize: '1.125rem', fontWeight: 600 }}>{cycle.name}</h2>
                <span className={`badge badge-${getStatusBadge(cycle.status)}`}>
                  {cycle.status}
                </span>
              </div>
              
              {cycle.description && (
                <p style={{ color: 'var(--text-secondary)', fontSize: '0.875rem', marginBottom: '1rem' }}>
                  {cycle.description}
                </p>
              )}

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Budget</div>
                  <div style={{ fontWeight: 600 }}>${cycle.budgetTotal?.toLocaleString()}</div>
                </div>
                <div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Grant Range</div>
                  <div style={{ fontWeight: 600 }}>${cycle.minGrantAmount?.toLocaleString()} - ${cycle.maxGrantAmount?.toLocaleString()}</div>
                </div>
                <div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Application Deadline</div>
                  <div style={{ fontWeight: 600 }}>{new Date(cycle.applicationDeadline).toLocaleDateString()}</div>
                </div>
                <div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Review Deadline</div>
                  <div style={{ fontWeight: 600 }}>{new Date(cycle.reviewDeadline).toLocaleDateString()}</div>
                </div>
              </div>

              {isAcceptingApplications(cycle) && (
                <a href="/applications/new" className="btn btn-primary" style={{ width: '100%' }}>
                  Apply Now
                </a>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div className="card text-center" style={{ padding: '3rem' }}>
          <p style={{ color: 'var(--text-secondary)' }}>No grant cycles available at the moment</p>
        </div>
      )}
    </div>
  );
};

export default GrantCycles;
