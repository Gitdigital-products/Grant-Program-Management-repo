import React, { useState, useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Applications from './pages/Applications';
import ApplicationForm from './pages/ApplicationForm';
import ApplicationDetail from './pages/ApplicationDetail';
import GrantCycles from './pages/GrantCycles';
import ReviewPanel from './pages/ReviewPanel';
import AdminPanel from './pages/AdminPanel';
import Analytics from './pages/Analytics';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import LoadingSpinner from './components/LoadingSpinner';
import './App.css';

// Protected Route Component
const ProtectedRoute = ({ children, roles }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return <LoadingSpinner />;
  }

  if (!user) {
    return <Navigate to="/login" />;
  }

  if (roles && !roles.includes(user.role)) {
    return <Navigate to="/dashboard" />;
  }

  return children;
};

// Main Layout Component
const MainLayout = ({ children }) => {
  const { user } = useAuth();

  return (
    <div className="app-layout">
      <Navbar />
      <div className="app-container">
        <Sidebar />
        <main className="main-content">
          {children}
        </main>
      </div>
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <Routes>
        {/* Public Routes */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        
        {/* Protected Routes */}
        <Route path="/dashboard" element={
          <ProtectedRoute>
            <MainLayout>
              <Dashboard />
            </MainLayout>
          </ProtectedRoute>
        } />
        
        <Route path="/applications" element={
          <ProtectedRoute>
            <MainLayout>
              <Applications />
            </MainLayout>
          </ProtectedRoute>
        } />
        
        <Route path="/applications/new" element={
          <ProtectedRoute roles={['applicant', 'admin']}>
            <MainLayout>
              <ApplicationForm />
            </MainLayout>
          </ProtectedRoute>
        } />
        
        <Route path="/applications/:id" element={
          <ProtectedRoute>
            <MainLayout>
              <ApplicationDetail />
            </MainLayout>
          </ProtectedRoute>
        } />
        
        <Route path="/grant-cycles" element={
          <ProtectedRoute>
            <MainLayout>
              <GrantCycles />
            </MainLayout>
          </ProtectedRoute>
        } />
        
        <Route path="/review" element={
          <ProtectedRoute roles={['reviewer', 'admin']}>
            <MainLayout>
              <ReviewPanel />
            </MainLayout>
          </ProtectedRoute>
        } />
        
        <Route path="/admin" element={
          <ProtectedRoute roles={['admin']}>
            <MainLayout>
              <AdminPanel />
            </MainLayout>
          </ProtectedRoute>
        } />
        
        <Route path="/analytics" element={
          <ProtectedRoute roles={['admin']}>
            <MainLayout>
              <Analytics />
            </MainLayout>
          </ProtectedRoute>
        } />
        
        {/* Default redirect */}
        <Route path="/" element={<Navigate to="/dashboard" />} />
        <Route path="*" element={<Navigate to="/dashboard" />} />
      </Routes>
    </AuthProvider>
  );
}

export default App;
