# Contributing to Grant Program Management

Thank you for your interest in contributing to the Grant Program Management system!

## How to Contribute

### Reporting Bugs

1. Check if the bug has already been reported
2. Create a detailed bug report including:
   - Clear title and description
   - Steps to reproduce
   - Expected vs actual behavior
   - Screenshots (if applicable)
   - Your environment details

### Suggesting Features

1. Check the existing issues and discussions
2. Clearly describe the feature
3. Explain why this feature would be useful
4. Provide examples or mockups if possible

### Pull Requests

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Make your changes and commit them
4. Push to your fork: `git push origin feature/my-feature`
5. Create a Pull Request

## Development Setup

### Prerequisites

- Node.js v18+
- MongoDB v6+
- Python 3.8+

### Local Development

1. Clone the repository
2. Install dependencies:
```bash
npm install
cd server && npm install
cd ../client && npm install
```

3. Set up environment variables (see `.env.example`)

4. Start the development server:
```bash
npm run dev
```

## Coding Standards

### JavaScript/Node.js

- Use ES6+ syntax
- Follow the existing code style
- Use meaningful variable and function names
- Add comments for complex logic
- Write unit tests for new features

### React

- Use functional components with hooks
- Follow React best practices
- Use meaningful component names
- Keep components small and focused

### Git Commit Messages

- Use clear, descriptive commit messages
- Start with a verb (Add, Fix, Update, etc.)
- Reference issue numbers when applicable

## Code of Conduct

- Be respectful and inclusive
- Welcome newcomers and help them learn
- Accept constructive criticism professionally
- Focus on what is best for the community

## Questions?

If you have any questions, feel free to open an issue or start a discussion.
