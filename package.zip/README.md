# Grant Program Management

A comprehensive toolkit for managing developer grant programs, including application workflows, review processes, and program administration.

## Features

- **Grant Application Management**: Create, submit, and manage grant applications
- **Reviewer Assignment & Workflows**: Assign reviewers and manage the review process
- **Application Scoring & Evaluation**: Score applications using customizable rubrics
- **Program Analytics & Reporting**: Track program performance with detailed analytics
- **Role-Based Access Control**: Separate interfaces for admins, reviewers, and applicants
- **RESTful API**: Complete backend API with JWT authentication

## Tech Stack

### Backend
- Node.js
- Express.js
- MongoDB (Mongoose)
- JWT Authentication

### Frontend
- React
- React Router
- Axios
- CSS

### Analytics
- Python
- Data processing and analysis

## Quick Start

### Prerequisites

- Node.js v18 or higher
- MongoDB v6 or higher
- Python 3.8+

### Installation

```bash
# Clone the repository
git clone https://github.com/Gitdigital-products/Grant-Program-Management-repo
cd Grant-Program-Management-repo

# Install all dependencies
npm run install-all

# Set up environment variables
cp server/.env.example server/.env
# Edit server/.env with your configuration

# Start the development server
npm run dev
```

The application will be available at:
- Frontend: http://localhost:3000
- Backend API: http://localhost:5000

## Project Structure

```
.
├── client/                 # React frontend
│   ├── public/
│   └── src/
│       ├── components/     # Reusable UI components
│       ├── context/       # React contexts
│       ├── pages/         # Page components
│       └── App.js         # Main app component
├── server/                 # Node.js backend
│   ├── config/           # Database configuration
│   ├── controllers/      # Route controllers
│   ├── middleware/      # Express middleware
│   ├── models/          # Mongoose models
│   ├── routes/          # API routes
│   ├── scripts/         # Python analytics scripts
│   └── server.js        # Server entry point
├── docs/                 # Documentation
│   ├── API.md           # API documentation
│   └── DEPLOYMENT.md    # Deployment guide
├── package.json          # Root package configuration
└── README.md            # This file
```

## User Roles

| Role | Description |
|------|-------------|
| **Admin** | Full access to all features, user management, analytics |
| **Reviewer** | Review and score applications assigned to them |
| **Applicant** | Submit and manage grant applications |

## API Documentation

See [API.md](docs/API.md) for detailed API documentation.

## Deployment

See [DEPLOYMENT.md](docs/DEPLOYMENT.md) for deployment instructions.

## License

MIT License - see [LICENSE](LICENSE) for details

## Contributing

Contributions are welcome! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

---

Built with ❤️ by GitDigital Products
