# Grant Program Management System - API Documentation

## Overview

This document provides comprehensive API documentation for the Grant Program Management System. The API is built using Node.js and Express, with MongoDB as the database.

## Base URL

```
http://localhost:5000/api
```

## Authentication

Most endpoints require authentication using JWT (JSON Web Tokens). Include the token in the Authorization header:

```
Authorization: Bearer <your_jwt_token>
```

## User Roles

- **admin**: Full access to all features
- **reviewer**: Can review and score applications
- **applicant**: Can submit and manage applications

## Endpoints

### Authentication

#### Register User
```
POST /auth/register
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "password123",
  "role": "applicant", // optional, defaults to "applicant"
  "organization": "My Company", // optional
  "bio": "Brief bio" // optional
}
```

#### Login
```
POST /auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "password123"
}

Response:
{
  "status": "success",
  "data": {
    "_id": "...",
    "name": "John Doe",
    "email": "john@example.com",
    "role": "applicant",
    "token": "eyJhbGciOiJIUzI1NiIs..."
  }
}
```

#### Get Current User
```
GET /auth/me
Headers: Authorization: Bearer <token>
```

### Applications

#### Create Application
```
POST /applications
Headers: Authorization: Bearer <token>
Content-Type: application/json

{
  "grantCycle": "cycle_id",
  "title": "My Project",
  "summary": "Brief summary",
  "fullProposal": "Detailed proposal",
  "budgetRequested": 10000,
  "budgetBreakdown": {
    "personnel": 5000,
    "equipment": 2000,
    "services": 2000,
    "other": 1000,
    "description": "Budget details"
  },
  "timeline": "Project timeline",
  "teamMembers": [
    { "name": "Member 1", "role": "Developer", "experience": "5 years" }
  ]
}
```

#### Get Applications
```
GET /applications
Query Parameters:
- status: Filter by status (draft, submitted, under_review, approved, rejected)
- grantCycle: Filter by grant cycle ID
- page: Page number (default: 1)
- limit: Items per page (default: 10)

Headers: Authorization: Bearer <token>
```

#### Get Application by ID
```
GET /applications/:id
Headers: Authorization: Bearer <token>
```

#### Update Application
```
PUT /applications/:id
Headers: Authorization: Bearer <token>
Content-Type: application/json

{
  "title": "Updated Title",
  "summary": "Updated summary"
}
```

#### Submit Application
```
POST /applications/:id/submit
Headers: Authorization: Bearer <token>
```

#### Update Application Status (Admin only)
```
PATCH /applications/:id/status
Headers: Authorization: Bearer <token>
Content-Type: application/json

{
  "status": "approved",
  "notes": "Application approved"
}
```

#### Assign Reviewers (Admin only)
```
POST /applications/:id/assign
Headers: Authorization: Bearer <token>
Content-Type: application/json

{
  "reviewerIds": ["reviewer_id_1", "reviewer_id_2"]
}
```

### Grant Cycles

#### Get All Grant Cycles
```
GET /grant-cycles
Query Parameters:
- status: Filter by status
- page: Page number
- limit: Items per page
```

#### Get Active Grant Cycles
```
GET /grant-cycles/active
```

#### Get Grant Cycle by ID
```
GET /grant-cycles/:id
```

#### Create Grant Cycle (Admin only)
```
POST /grant-cycles
Headers: Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "Q1 2024 Grant Program",
  "description": "Grant program for Q1 2024",
  "budgetTotal": 100000,
  "maxGrantAmount": 25000,
  "minGrantAmount": 5000,
  "startDate": "2024-01-01",
  "endDate": "2024-03-31",
  "applicationDeadline": "2024-02-15",
  "reviewDeadline": "2024-03-15",
  "status": "active",
  "rubric": {
    "criteria": [
      { "name": "technicalFeasibility", "weight": 20, "maxScore": 10 },
      { "name": "impact", "weight": 25, "maxScore": 10 }
    ]
  },
  "guidelines": "Program guidelines"
}
```

#### Update Grant Cycle (Admin only)
```
PUT /grant-cycles/:id
Headers: Authorization: Bearer <token>
```

### Reviews

#### Create Review (Reviewer only)
```
POST /reviews
Headers: Authorization: Bearer <token>
Content-Type: application/json

{
  "application": "application_id",
  "scores": {
    "technicalFeasibility": 8,
    "impact": 9,
    "innovation": 7,
    "sustainability": 8,
    "teamCapability": 9
  },
  "comments": "Review comments",
  "strengths": ["Strong team", "Innovative approach"],
  "weaknesses": ["Budget could be clearer"],
  "recommendation": "approve",
  "recommendationReason": "Recommended for approval"
}
```

#### Get Pending Reviews
```
GET /reviews/pending
Headers: Authorization: Bearer <token>
```

#### Get Reviews
```
GET /reviews
Query Parameters:
- application: Filter by application ID
- page: Page number
- limit: Items per page
Headers: Authorization: Bearer <token>
```

### Users

#### Get All Users (Admin only)
```
GET /users
Query Parameters:
- role: Filter by role
- isActive: Filter by active status
- search: Search by name or email
- page: Page number
- limit: Items per page
Headers: Authorization: Bearer <token>
```

#### Get Reviewers (Admin only)
```
GET /users/reviewers
Headers: Authorization: Bearer <token>
```

#### Update User
```
PUT /users/:id
Headers: Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "Updated Name",
  "role": "reviewer", // Admin only
  "isActive": false // Admin only
}
```

### Analytics

#### Get Dashboard Summary (Admin only)
```
GET /analytics/summary
Headers: Authorization: Bearer <token>
```

#### Get Dashboard Data
```
GET /analytics/dashboard
Headers: Authorization: Bearer <token>
```

#### Export Applications (Admin only)
```
GET /analytics/export
Headers: Authorization: Bearer <token>
Returns: CSV file
```

## Response Formats

### Success Response
```json
{
  "status": "success",
  "data": { ... }
}
```

### Error Response
```json
{
  "status": "error",
  "message": "Error message"
}
```

### Paginated Response
```json
{
  "status": "success",
  "data": [...],
  "pagination": {
    "total": 100,
    "page": 1,
    "pages": 10
  }
}
```

## Status Codes

- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `500` - Internal Server Error
