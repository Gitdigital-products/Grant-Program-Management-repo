# Grant Program Management - Deployment Guide

This guide provides instructions for deploying the Grant Program Management system in various environments.

## Prerequisites

- Node.js (v18 or higher)
- MongoDB (v6 or higher)
- Python 3.8+ (for analytics)
- npm or yarn

## Environment Setup

### 1. Clone the Repository

```bash
git clone https://github.com/Gitdigital-products/Grant-Program-Management-repo
cd Grant-Program-Management-repo
```

### 2. Install Dependencies

```bash
# Install root dependencies
npm install

# Install server dependencies
cd server
npm install

# Install client dependencies
cd ../client
npm install
```

### 3. Configure Environment Variables

Create a `.env` file in the `server` directory:

```env
# Server Configuration
NODE_ENV=development
PORT=5000

# Database Configuration
MONGO_URI=mongodb://localhost:27017/grant_program_db

# JWT Configuration
JWT_SECRET=your-super-secret-jwt-key-change-in-production
JWT_EXPIRE=30d

# Frontend URL (for CORS)
FRONTEND_URL=http://localhost:3000

# Python Configuration (for analytics)
PYTHON_PATH=python3
```

### 4. Start the Application

#### Development Mode

```bash
# Run both server and client
npm run dev

# Or run separately
# Terminal 1 - Server
cd server
npm run dev

# Terminal 2 - Client
cd client
npm start
```

#### Production Mode

```bash
# Build the client
cd client
npm run build

# Start the server
cd ../server
npm start
```

## MongoDB Setup

### Local MongoDB

1. Install MongoDB Community Server
2. Start MongoDB:
```bash
mongod
```

### MongoDB Atlas (Cloud)

1. Create a free account at [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
2. Create a new cluster
3. Create a database user
4. Get the connection string
5. Update `MONGO_URI` in your `.env` file

## Deployment Options

### Heroku

1. Install Heroku CLI
2. Create a Heroku app:
```bash
heroku create grant-program-management
```

3. Set environment variables:
```bash
heroku config:set MONGO_URI=your_mongodb_uri
heroku config:set JWT_SECRET=your_jwt_secret
heroku config:set NODE_ENV=production
```

4. Deploy:
```bash
git push heroku main
```

### Docker

Create a `Dockerfile`:

```dockerfile
FROM node:18

WORKDIR /app

COPY package*.json ./
RUN npm install

COPY server ./server
COPY client ./client
COPY docs ./docs

WORKDIR /app/server
RUN npm install --production

EXPOSE 5000

CMD ["npm", "start"]
```

Build and run:
```bash
docker build -t grant-program-management .
docker run -p 5000:5000 grant-program-management
```

### AWS EC2

1. Launch an EC2 instance (Ubuntu 20.04)
2. Install Node.js, MongoDB, and Nginx
3. Clone the repository
4. Set up environment variables
5. Use PM2 to manage the Node.js process:
```bash
npm install -g pm2
cd server
pm2 start server.js
```

## Nginx Configuration

Example Nginx configuration for reverse proxy:

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    location /api {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## Security Considerations

1. **JWT Secret**: Use a strong, random secret key
2. **Environment Variables**: Never commit sensitive data to version control
3. **HTTPS**: Always use HTTPS in production
4. **Rate Limiting**: Implement rate limiting for API endpoints
5. **Input Validation**: Validate all user inputs
6. **CORS**: Configure CORS properly for production

## Monitoring

### Logging

The application uses console logging. For production, consider using:
- Winston
- Morgan
- PM2 logs

### Health Check

Access the health check endpoint:
```

```

## Troubleshooting

### CommonGET /api/health Issues

1. **MongoDB Connection Error**
   - Check if MongoDB is running
   - Verify the connection string
   - Check firewall settings

2. **JWT Token Issues**
   - Verify JWT_SECRET is set
   - Check token expiration
   - Ensure proper Authorization header format

3. **CORS Errors**
   - Update FRONTEND_URL in environment variables
   - Check CORS configuration in server.js

4. **Client Build Errors**
   - Clear node_modules and reinstall
   - Check for missing environment variables

## Backup and Restore

### MongoDB Backup

```bash
mongodump --db grant_program_db --out /backup/path
```

### MongoDB Restore

```bash
mongorestore /backup/path/grant_program_db
```
