const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Application = require('../models/Application');
const { protect, authorize } = require('../middleware/auth');
const { idValidation } = require('../middleware/validation');

// @route   GET /api/users
// @desc    Get all users
// @access  Private (Admin)
router.get('/', protect, authorize('admin'), async (req, res) => {
  try {
    const { role, isActive, page = 1, limit = 20, search } = req.query;
    let query = {};

    if (role) query.role = role;
    if (isActive !== undefined) query.isActive = isActive === 'true';
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } }
      ];
    }

    const users = await User.find(query)
      .select('-password')
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit));

    const total = await User.countDocuments(query);

    res.json({
      status: 'success',
      data: users,
      pagination: {
        total,
        page: parseInt(page),
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   GET /api/users/reviewers
// @desc    Get all reviewers
// @access  Private (Admin)
router.get('/reviewers', protect, authorize('admin'), async (req, res) => {
  try {
    const reviewers = await User.find({ role: 'reviewer', isActive: true })
      .select('name email bio organization');

    res.json({
      status: 'success',
      data: reviewers
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   GET /api/users/:id
// @desc    Get user by ID
// @access  Private
router.get('/:id', protect, idValidation, async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password');

    if (!user) {
      return res.status(404).json({ 
        status: 'error',
        message: 'User not found' 
      });
    }

    // Get user statistics
    let stats = {};
    
    if (user.role === 'reviewer') {
      const assignedCount = await Application.countDocuments({ reviewers: user._id });
      const completedReviews = await Application.countDocuments({ 
        reviewers: user._id,
        status: { $in: ['approved', 'rejected'] }
      });
      stats = { assignedCount, completedReviews };
    } else if (user.role === 'applicant') {
      const applicationCount = await Application.countDocuments({ applicant: user._id });
      stats = { applicationCount };
    }

    res.json({
      status: 'success',
      data: {
        ...user.toObject(),
        stats
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   PUT /api/users/:id
// @desc    Update user
// @access  Private (Admin or own profile)
router.put('/:id', protect, idValidation, async (req, res) => {
  try {
    // Check authorization
    if (req.user.role !== 'admin' && req.user._id.toString() !== req.params.id) {
      return res.status(403).json({ 
        status: 'error',
        message: 'Not authorized to update this user' 
      });
    }

    const { name, bio, organization, avatar } = req.body;
    
    // Admin can update more fields
    let updates = { name, bio, organization, avatar };
    
    if (req.user.role === 'admin') {
      const { role, isActive } = req.body;
      if (role) updates.role = role;
      if (isActive !== undefined) updates.isActive = isActive;
    }

    // Remove undefined values
    Object.keys(updates).forEach(key => 
      updates[key] === undefined && delete updates[key]
    );

    const user = await User.findByIdAndUpdate(
      req.params.id,
      updates,
      { new: true, runValidators: true }
    ).select('-password');

    if (!user) {
      return res.status(404).json({ 
        status: 'error',
        message: 'User not found' 
      });
    }

    res.json({
      status: 'success',
      data: user
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   DELETE /api/users/:id
// @desc    Deactivate user (soft delete)
// @access  Private (Admin)
router.delete('/:id', protect, authorize('admin'), idValidation, async (req, res) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({ 
        status: 'error',
        message: 'User not found' 
      });
    }

    // Prevent self-deletion
    if (user._id.toString() === req.user._id.toString()) {
      return res.status(400).json({ 
        status: 'error',
        message: 'Cannot deactivate your own account' 
      });
    }

    user.isActive = false;
    await user.save();

    res.json({
      status: 'success',
      message: 'User deactivated successfully'
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   POST /api/users/:id/reactivate
// @desc    Reactivate user
// @access  Private (Admin)
router.post('/:id/reactivate', protect, authorize('admin'), idValidation, async (req, res) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({ 
        status: 'error',
        message: 'User not found' 
      });
    }

    user.isActive = true;
    await user.save();

    res.json({
      status: 'success',
      data: user
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

module.exports = router;
