const express = require('express');
const router = express.Router();
const Review = require('../models/Review');
const Application = require('../models/Application');
const { protect, authorize } = require('../middleware/auth');
const { reviewValidation, idValidation } = require('../middleware/validation');

// @route   POST /api/reviews
// @desc    Create a new review
// @access  Private (Reviewer)
router.post('/', protect, authorize('reviewer', 'admin'), reviewValidation.create, async (req, res) => {
  try {
    const { application: applicationId, scores, comments, strengths, weaknesses, questions, recommendation, recommendationReason } = req.body;

    // Check if application exists
    const application = await Application.findById(applicationId);
    if (!application) {
      return res.status(404).json({ 
        status: 'error',
        message: 'Application not found' 
      });
    }

    // Check if reviewer is assigned
    if (!application.reviewers.includes(req.user._id)) {
      return res.status(403).json({ 
        status: 'error',
        message: 'You are not assigned to review this application' 
      });
    }

    // Check if review already exists
    const existingReview = await Review.findOne({
      reviewer: req.user._id,
      application: applicationId
    });

    if (existingReview) {
      return res.status(400).json({ 
        status: 'error',
        message: 'You have already reviewed this application' 
      });
    }

    // Create review
    const review = await Review.create({
      reviewer: req.user._id,
      application: applicationId,
      scores,
      comments,
      strengths,
      weaknesses,
      questions,
      recommendation,
      recommendationReason,
      status: 'submitted',
      submittedAt: new Date()
    });

    // Update application with review reference and recalculate scores
    application.reviews.push(review._id);
    
    // Recalculate average score
    const allReviews = await Review.find({ application: applicationId });
    const totalScore = allReviews.reduce((sum, r) => sum + r.totalScore, 0);
    application.averageScore = totalScore / allReviews.length;
    application.scores = {
      technicalFeasibility: allReviews.reduce((sum, r) => sum + (r.scores.technicalFeasibility || 0), 0) / allReviews.length,
      impact: allReviews.reduce((sum, r) => sum + (r.scores.impact || 0), 0) / allReviews.length,
      innovation: allReviews.reduce((sum, r) => sum + (r.scores.innovation || 0), 0) / allReviews.length,
      sustainability: allReviews.reduce((sum, r) => sum + (r.scores.sustainability || 0), 0) / allReviews.length,
      teamCapability: allReviews.reduce((sum, r) => sum + (r.scores.teamCapability || 0), 0) / allReviews.length
    };
    
    await application.save();

    res.status(201).json({
      status: 'success',
      data: review
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   GET /api/reviews
// @desc    Get all reviews
// @access  Private
router.get('/', protect, async (req, res) => {
  try {
    const { application, page = 1, limit = 10 } = req.query;
    let query = {};

    // Filter based on role
    if (req.user.role === 'reviewer') {
      query.reviewer = req.user._id;
    }

    if (application) query.application = application;

    const reviews = await Review.find(query)
      .populate('reviewer', 'name email')
      .populate('application', 'title status')
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit));

    const total = await Review.countDocuments(query);

    res.json({
      status: 'success',
      data: reviews,
      pagination: {
        total,
        page: parseInt(page),
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   GET /api/reviews/pending
// @desc    Get pending reviews for current reviewer
// @access  Private (Reviewer)
router.get('/pending', protect, authorize('reviewer', 'admin'), async (req, res) => {
  try {
    const applications = await Application.find({
      reviewers: req.user._id,
      status: 'under_review'
    })
    .populate('applicant', 'name email organization')
    .populate('grantCycle', 'name');

    // Get existing reviews
    const reviews = await Review.find({ reviewer: req.user._id });
    const reviewedApplicationIds = reviews.map(r => r.application.toString());

    // Filter out already reviewed applications
    const pendingApplications = applications.filter(
      app => !reviewedApplicationIds.includes(app._id.toString())
    );

    res.json({
      status: 'success',
      data: pendingApplications
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   GET /api/reviews/:id
// @desc    Get review by ID
// @access  Private
router.get('/:id', protect, idValidation, async (req, res) => {
  try {
    const review = await Review.findById(req.params.id)
      .populate('reviewer', 'name email')
      .populate('application');

    if (!review) {
      return res.status(404).json({ 
        status: 'error',
        message: 'Review not found' 
      });
    }

    // Check if user has access
    if (req.user.role === 'reviewer' && review.reviewer._id.toString() !== req.user._id.toString()) {
      return res.status(403).json({ 
        status: 'error',
        message: 'Not authorized to view this review' 
      });
    }

    res.json({
      status: 'success',
      data: review
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   PUT /api/reviews/:id
// @desc    Update review
// @access  Private (Reviewer - pending only)
router.put('/:id', protect, idValidation, async (req, res) => {
  try {
    let review = await Review.findById(req.params.id);

    if (!review) {
      return res.status(404).json({ 
        status: 'error',
        message: 'Review not found' 
      });
    }

    // Check ownership
    if (review.reviewer.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ 
        status: 'error',
        message: 'Not authorized to update this review' 
      });
    }

    if (review.status === 'submitted' && req.user.role !== 'admin') {
      return res.status(400).json({ 
        status: 'error',
        message: 'Cannot update submitted review' 
      });
    }

    const allowedUpdates = ['scores', 'comments', 'strengths', 'weaknesses', 'questions', 'recommendation', 'recommendationReason'];
    const updates = {};
    
    allowedUpdates.forEach(field => {
      if (req.body[field] !== undefined) {
        updates[field] = req.body[field];
      }
    });

    updates.status = 'revised';
    updates.revisedAt = new Date();

    review = await Review.findByIdAndUpdate(
      req.params.id,
      updates,
      { new: true, runValidators: true }
    );

    res.json({
      status: 'success',
      data: review
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   DELETE /api/reviews/:id
// @desc    Delete review
// @access  Private (Admin)
router.delete('/:id', protect, authorize('admin'), idValidation, async (req, res) => {
  try {
    const review = await Review.findById(req.params.id);

    if (!review) {
      return res.status(404).json({ 
        status: 'error',
        message: 'Review not found' 
      });
    }

    // Remove review from application
    await Application.findByIdAndUpdate(review.application, {
      $pull: { reviews: review._id }
    });

    await review.deleteOne();

    res.json({
      status: 'success',
      message: 'Review deleted successfully'
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

module.exports = router;
