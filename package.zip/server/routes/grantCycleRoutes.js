const express = require('express');
const router = express.Router();
const GrantCycle = require('../models/GrantCycle');
const Application = require('../models/Application');
const { protect, authorize } = require('../middleware/auth');
const { grantCycleValidation, idValidation } = require('../middleware/validation');

// @route   POST /api/grant-cycles
// @desc    Create a new grant cycle
// @access  Private (Admin)
router.post('/', protect, authorize('admin'), grantCycleValidation.create, async (req, res) => {
  try {
    const { 
      name, 
      description, 
      budgetTotal, 
      maxGrantAmount, 
      minGrantAmount,
      startDate, 
      endDate, 
      applicationDeadline,
      reviewDeadline,
      status,
      rubric,
      requiredDocuments,
      guidelines,
      isPublic
    } = req.body;

    // Validate dates
    if (new Date(applicationDeadline) > new Date(endDate)) {
      return res.status(400).json({ 
        status: 'error',
        message: 'Application deadline must be before end date' 
      });
    }

    if (minGrantAmount > maxGrantAmount) {
      return res.status(400).json({ 
        status: 'error',
        message: 'Minimum grant amount cannot exceed maximum' 
      });
    }

    const grantCycle = await GrantCycle.create({
      name,
      description,
      budgetTotal,
      maxGrantAmount,
      minGrantAmount,
      startDate,
      endDate,
      applicationDeadline,
      reviewDeadline,
      status: status || 'draft',
      rubric,
      requiredDocuments,
      guidelines,
      isPublic,
      createdBy: req.user._id
    });

    res.status(201).json({
      status: 'success',
      data: grantCycle
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   GET /api/grant-cycles
// @desc    Get all grant cycles
// @access  Public
router.get('/', async (req, res) => {
  try {
    const { status, page = 1, limit = 10, upcoming } = req.query;
    let query = {};

    // Public users only see public cycles
    if (!req.user || req.user.role === 'applicant') {
      query.isPublic = true;
    }

    if (status) query.status = status;
    if (upcoming === 'true') {
      query.startDate = { $gt: new Date() };
    }

    const grantCycles = await GrantCycle.find(query)
      .populate('createdBy', 'name email')
      .sort({ startDate: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit));

    const total = await GrantCycle.countDocuments(query);

    res.json({
      status: 'success',
      data: grantCycles,
      pagination: {
        total,
        page: parseInt(page),
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   GET /api/grant-cycles/active
// @desc    Get active grant cycle
// @access  Public
router.get('/active', async (req, res) => {
  try {
    const grantCycle = await GrantCycle.findOne({ 
      status: 'active',
      isPublic: true,
      applicationDeadline: { $gt: new Date() }
    })
    .populate('createdBy', 'name');

    if (!grantCycle) {
      return res.status(404).json({ 
        status: 'error',
        message: 'No active grant cycle found' 
      });
    }

    res.json({
      status: 'success',
      data: grantCycle
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   GET /api/grant-cycles/:id
// @desc    Get grant cycle by ID
// @access  Public
router.get('/:id', idValidation, async (req, res) => {
  try {
    const grantCycle = await GrantCycle.findById(req.params.id)
      .populate('createdBy', 'name email');

    if (!grantCycle) {
      return res.status(404).json({ 
        status: 'error',
        message: 'Grant cycle not found' 
      });
    }

    // Get statistics
    const stats = await Application.aggregate([
      { $match: { grantCycle: grantCycle._id } },
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 }
        }
      }
    ]);

    const applicationStats = stats.reduce((acc, curr) => {
      acc[curr._id] = curr.count;
      return acc;
    }, {});

    res.json({
      status: 'success',
      data: {
        ...grantCycle.toObject(),
        applicationStats
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   PUT /api/grant-cycles/:id
// @desc    Update grant cycle
// @access  Private (Admin)
router.put('/:id', protect, authorize('admin'), idValidation, async (req, res) => {
  try {
    let grantCycle = await GrantCycle.findById(req.params.id);

    if (!grantCycle) {
      return res.status(404).json({ 
        status: 'error',
        message: 'Grant cycle not found' 
      });
    }

    const allowedUpdates = [
      'name', 'description', 'budgetTotal', 'maxGrantAmount', 'minGrantAmount',
      'startDate', 'endDate', 'applicationDeadline', 'reviewDeadline',
      'status', 'rubric', 'requiredDocuments', 'guidelines', 'isPublic'
    ];
    
    const updates = {};
    allowedUpdates.forEach(field => {
      if (req.body[field] !== undefined) {
        updates[field] = req.body[field];
      }
    });

    grantCycle = await GrantCycle.findByIdAndUpdate(
      req.params.id,
      updates,
      { new: true, runValidators: true }
    );

    res.json({
      status: 'success',
      data: grantCycle
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   PATCH /api/grant-cycles/:id/status
// @desc    Update grant cycle status
// @access  Private (Admin)
router.patch('/:id/status', protect, authorize('admin'), idValidation, async (req, res) => {
  try {
    const { status } = req.body;
    const validStatuses = ['draft', 'active', 'reviewing', 'closed', 'completed'];

    if (!validStatuses.includes(status)) {
      return res.status(400).json({ 
        status: 'error',
        message: 'Invalid status' 
      });
    }

    const grantCycle = await GrantCycle.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true }
    );

    if (!grantCycle) {
      return res.status(404).json({ 
        status: 'error',
        message: 'Grant cycle not found' 
      });
    }

    res.json({
      status: 'success',
      data: grantCycle
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   DELETE /api/grant-cycles/:id
// @desc    Delete grant cycle
// @access  Private (Admin)
router.delete('/:id', protect, authorize('admin'), idValidation, async (req, res) => {
  try {
    const grantCycle = await GrantCycle.findById(req.params.id);

    if (!grantCycle) {
      return res.status(404).json({ 
        status: 'error',
        message: 'Grant cycle not found' 
      });
    }

    // Check if there are applications
    const applicationCount = await Application.countDocuments({ grantCycle: req.params.id });
    if (applicationCount > 0) {
      return res.status(400).json({ 
        status: 'error',
        message: 'Cannot delete grant cycle with applications' 
      });
    }

    await grantCycle.deleteOne();

    res.json({
      status: 'success',
      message: 'Grant cycle deleted successfully'
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

module.exports = router;
