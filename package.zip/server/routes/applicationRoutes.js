const express = require('express');
const router = express.Router();
const Application = require('../models/Application');
const GrantCycle = require('../models/GrantCycle');
const Review = require('../models/Review');
const { protect, authorize } = require('../middleware/auth');
const { applicationValidation, idValidation } = require('../middleware/validation');

// @route   POST /api/applications
// @desc    Create a new application
// @access  Private (Applicant)
router.post('/', protect, authorize('applicant', 'admin'), applicationValidation.create, async (req, res) => {
  try {
    const { grantCycle, title, summary, fullProposal, budgetRequested, budgetBreakdown, timeline, teamMembers } = req.body;

    // Check if grant cycle exists and is active
    const cycle = await GrantCycle.findById(grantCycle);
    if (!cycle) {
      return res.status(404).json({ 
        status: 'error',
        message: 'Grant cycle not found' 
      });
    }

    if (cycle.status !== 'active') {
      return res.status(400).json({ 
        status: 'error',
        message: 'Grant cycle is not accepting applications' 
      });
    }

    // Check if budget is within cycle limits
    if (budgetRequested > cycle.maxGrantAmount || budgetRequested < cycle.minGrantAmount) {
      return res.status(400).json({ 
        status: 'error',
        message: `Budget must be between ${cycle.minGrantAmount} and ${cycle.maxGrantAmount}` 
      });
    }

    // Check if user already has an application for this cycle
    const existingApplication = await Application.findOne({
      applicant: req.user._id,
      grantCycle
    });

    if (existingApplication) {
      return res.status(400).json({ 
        status: 'error',
        message: 'You already have an application for this grant cycle' 
      });
    }

    const application = await Application.create({
      applicant: req.user._id,
      grantCycle,
      title,
      summary,
      fullProposal,
      budgetRequested,
      budgetBreakdown,
      timeline,
      teamMembers,
      status: 'draft'
    });

    res.status(201).json({
      status: 'success',
      data: application
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   GET /api/applications
// @desc    Get all applications (filtered by role)
// @access  Private
router.get('/', protect, async (req, res) => {
  try {
    const { status, grantCycle, page = 1, limit = 10 } = req.query;
    let query = {};

    // Filter based on role
    if (req.user.role === 'applicant') {
      query.applicant = req.user._id;
    } else if (req.user.role === 'reviewer') {
      query.reviewers = req.user._id;
    }

    // Additional filters
    if (status) query.status = status;
    if (grantCycle) query.grantCycle = grantCycle;

    const applications = await Application.find(query)
      .populate('applicant', 'name email organization')
      .populate('grantCycle', 'name status')
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit));

    const total = await Application.countDocuments(query);

    res.json({
      status: 'success',
      data: applications,
      pagination: {
        total,
        page: parseInt(page),
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   GET /api/applications/:id
// @desc    Get application by ID
// @access  Private
router.get('/:id', protect, idValidation, async (req, res) => {
  try {
    const application = await Application.findById(req.params.id)
      .populate('applicant', 'name email organization bio')
      .populate('grantCycle', 'name description rubric status')
      .populate('reviewers', 'name email')
      .populate('reviews');

    if (!application) {
      return res.status(404).json({ 
        status: 'error',
        message: 'Application not found' 
      });
    }

    // Check if user has access
    if (req.user.role === 'applicant' && application.applicant._id.toString() !== req.user._id.toString()) {
      return res.status(403).json({ 
        status: 'error',
        message: 'Not authorized to view this application' 
      });
    }

    res.json({
      status: 'success',
      data: application
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   PUT /api/applications/:id
// @desc    Update application
// @access  Private (Applicant - draft only, Admin)
router.put('/:id', protect, idValidation, async (req, res) => {
  try {
    let application = await Application.findById(req.params.id);

    if (!application) {
      return res.status(404).json({ 
        status: 'error',
        message: 'Application not found' 
      });
    }

    // Check ownership (applicants can only update their own drafts)
    if (req.user.role === 'applicant') {
      if (application.applicant.toString() !== req.user._id.toString()) {
        return res.status(403).json({ 
          status: 'error',
          message: 'Not authorized to update this application' 
        });
      }
      if (application.status !== 'draft') {
        return res.status(400).json({ 
          status: 'error',
          message: 'Can only update draft applications' 
        });
      }
    }

    const allowedUpdates = ['title', 'summary', 'fullProposal', 'budgetRequested', 'budgetBreakdown', 'timeline', 'teamMembers', 'documents'];
    const updates = {};
    
    allowedUpdates.forEach(field => {
      if (req.body[field] !== undefined) {
        updates[field] = req.body[field];
      }
    });

    application = await Application.findByIdAndUpdate(
      req.params.id,
      updates,
      { new: true, runValidators: true }
    );

    res.json({
      status: 'success',
      data: application
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   POST /api/applications/:id/submit
// @desc    Submit application
// @access  Private (Applicant)
router.post('/:id/submit', protect, idValidation, async (req, res) => {
  try {
    const application = await Application.findById(req.params.id);

    if (!application) {
      return res.status(404).json({ 
        status: 'error',
        message: 'Application not found' 
      });
    }

    if (application.applicant.toString() !== req.user._id.toString()) {
      return res.status(403).json({ 
        status: 'error',
        message: 'Not authorized to submit this application' 
      });
    }

    if (application.status !== 'draft') {
      return res.status(400).json({ 
        status: 'error',
        message: 'Application is already submitted' 
      });
    }

    application.status = 'submitted';
    application.submittedAt = new Date();
    await application.save();

    res.json({
      status: 'success',
      message: 'Application submitted successfully',
      data: application
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   PATCH /api/applications/:id/status
// @desc    Update application status
// @access  Private (Admin)
router.patch('/:id/status', protect, authorize('admin'), idValidation, async (req, res) => {
  try {
    const { status, notes } = req.body;
    const validStatuses = ['under_review', 'approved', 'rejected', 'revision_requested'];

    if (!validStatuses.includes(status)) {
      return res.status(400).json({ 
        status: 'error',
        message: 'Invalid status' 
      });
    }

    const application = await Application.findById(req.params.id);

    if (!application) {
      return res.status(404).json({ 
        status: 'error',
        message: 'Application not found' 
      });
    }

    application.status = status;
    application.notes = notes || application.notes;

    if (status === 'approved' || status === 'rejected') {
      application.decisionAt = new Date();
      application.decisionBy = req.user._id;
    }

    await application.save();

    res.json({
      status: 'success',
      data: application
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   POST /api/applications/:id/assign
// @desc    Assign reviewers to application
// @access  Private (Admin)
router.post('/:id/assign', protect, authorize('admin'), idValidation, async (req, res) => {
  try {
    const { reviewerIds } = req.body;

    const application = await Application.findById(req.params.id);

    if (!application) {
      return res.status(404).json({ 
        status: 'error',
        message: 'Application not found' 
      });
    }

    application.reviewers = reviewerIds;
    application.status = 'under_review';
    await application.save();

    res.json({
      status: 'success',
      data: application
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   DELETE /api/applications/:id
// @desc    Delete application
// @access  Private (Applicant - draft only, Admin)
router.delete('/:id', protect, authorize('admin'), idValidation, async (req, res) => {
  try {
    const application = await Application.findById(req.params.id);

    if (!application) {
      return res.status(404).json({ 
        status: 'error',
        message: 'Application not found' 
      });
    }

    await application.deleteOne();

    res.json({
      status: 'success',
      message: 'Application deleted successfully'
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

module.exports = router;
