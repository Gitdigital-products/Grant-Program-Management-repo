const express = require('express');
const router = express.Router();
const { spawn } = require('child_process');
const path = require('path');
const Application = require('../models/Application');
const GrantCycle = require('../models/GrantCycle');
const User = require('../models/User');
const Review = require('../models/Review');
const { protect, authorize } = require('../middleware/auth');

// @route   GET /api/analytics/summary
// @desc    Get program summary analytics
// @access  Private (Admin)
router.get('/summary', protect, authorize('admin'), async (req, res) => {
  try {
    // Get total counts
    const totalApplications = await Application.countDocuments();
    const totalApproved = await Application.countDocuments({ status: 'approved' });
    const totalRejected = await Application.countDocuments({ status: 'rejected' });
    const totalPending = await Application.countDocuments({ status: { $in: ['submitted', 'under_review'] } });

    // Budget analytics
    const budgetStats = await Application.aggregate([
      { $match: { status: 'approved' } },
      {
        $group: {
          _id: null,
          totalBudgetApproved: { $sum: '$budgetRequested' },
          avgBudgetApproved: { $avg: '$budgetRequested' },
          maxBudgetApproved: { $max: '$budgetRequested' },
          minBudgetApproved: { $min: '$budgetRequested' }
        }
      }
    ]);

    // Applications by status
    const statusBreakdown = await Application.aggregate([
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 }
        }
      }
    ]);

    // Applications by grant cycle
    const cycleBreakdown = await Application.aggregate([
      {
        $group: {
          _id: '$grantCycle',
          total: { $sum: 1 },
          approved: { $sum: { $cond: [{ $eq: ['$status', 'approved'] }, 1, 0] } },
          rejected: { $sum: { $cond: [{ $eq: ['$status', 'rejected'] }, 1, 0] } },
          budgetRequested: { $sum: '$budgetRequested' }
        }
      },
      {
        $lookup: {
          from: 'grantcycles',
          localField: '_id',
          foreignField: '_id',
          as: 'cycle'
        }
      },
      { $unwind: '$cycle' },
      {
        $project: {
          cycleName: '$cycle.name',
          total: 1,
          approved: 1,
          rejected: 1,
          budgetRequested: 1,
          approvalRate: { $multiply: [{ $divide: ['$approved', '$total'] }, 100] }
        }
      }
    ]);

    // Average scores
    const scoreStats = await Application.aggregate([
      { $match: { averageScore: { $gt: 0 } } },
      {
        $group: {
          _id: null,
          avgOverallScore: { $avg: '$averageScore' },
          avgTechnicalFeasibility: { $avg: '$scores.technicalFeasibility' },
          avgImpact: { $avg: '$scores.impact' },
          avgInnovation: { $avg: '$scores.innovation' },
          avgSustainability: { $avg: '$scores.sustainability' },
          avgTeamCapability: { $avg: '$scores.teamCapability' }
        }
      }
    ]);

    // Review analytics
    const reviewStats = await Review.aggregate([
      {
        $group: {
          _id: null,
          totalReviews: { $sum: 1 },
          avgScore: { $avg: '$totalScore' }
        }
      }
    ]);

    res.json({
      status: 'success',
      data: {
        applications: {
          total: totalApplications,
          approved: totalApproved,
          rejected: totalRejected,
          pending: totalPending,
          approvalRate: totalApplications > 0 ? (totalApproved / totalApplications * 100).toFixed(2) : 0
        },
        budget: budgetStats[0] || {
          totalBudgetApproved: 0,
          avgBudgetApproved: 0,
          maxBudgetApproved: 0,
          minBudgetApproved: 0
        },
        byStatus: statusBreakdown,
        byCycle: cycleBreakdown,
        scores: scoreStats[0] || {},
        reviews: reviewStats[0] || { totalReviews: 0, avgScore: 0 }
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   GET /api/analytics/python/summary
// @desc    Get Python analytics summary
// @access  Private (Admin)
router.get('/python/summary', protect, authorize('admin'), async (req, res) => {
  try {
    // Export data to JSON
    const applications = await Application.find().lean();
    const grantCycles = await GrantCycle.find().lean();

    const data = {
      applications,
      grantCycles,
      generatedAt: new Date()
    };

    // Write data to temp file
    const fs = require('fs');
    const tempFile = path.join(__dirname, '../tmp/analytics_data.json');
    
    // Ensure tmp directory exists
    const tmpDir = path.dirname(tempFile);
    if (!fs.existsSync(tmpDir)) {
      fs.mkdirSync(tmpDir, { recursive: true });
    }

    fs.writeFileSync(tempFile, JSON.stringify(data, null, 2));

    // Run Python script
    const pythonProcess = spawn('python', [
      path.join(__dirname, '../scripts/analytics_engine.py'),
      tempFile
    ]);

    let pythonOutput = '';
    let pythonError = '';

    pythonProcess.stdout.on('data', (data) => {
      pythonOutput += data.toString();
    });

    pythonProcess.stderr.on('data', (data) => {
      pythonError += data.toString();
    });

    pythonProcess.on('close', (code) => {
      if (code !== 0) {
        console.error('Python script error:', pythonError);
        return res.status(500).json({
          status: 'error',
          message: 'Analytics processing failed'
        });
      }

      try {
        const analytics = JSON.parse(pythonOutput);
        res.json({
          status: 'success',
          data: analytics
        });
      } catch (e) {
        res.status(500).json({
          status: 'error',
          message: 'Failed to parse analytics output'
        });
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   GET /api/analytics/dashboard
// @desc    Get dashboard data for current user
// @access  Private
router.get('/dashboard', protect, async (req, res) => {
  try {
    let data = {};

    if (req.user.role === 'admin') {
      // Admin dashboard
      const recentApplications = await Application.find()
        .populate('applicant', 'name email')
        .populate('grantCycle', 'name')
        .sort({ createdAt: -1 })
        .limit(5);

      const pendingReviews = await Application.countDocuments({ status: 'under_review' });
      const activeCycles = await GrantCycle.countDocuments({ status: 'active' });

      data = {
        recentApplications,
        pendingReviews,
        activeCycles
      };
    } else if (req.user.role === 'reviewer') {
      // Reviewer dashboard
      const assignedApplications = await Application.find({
        reviewers: req.user._id,
        status: 'under_review'
      })
      .populate('grantCycle', 'name')
      .populate('applicant', 'name email organization');

      const completedReviews = await Review.countDocuments({
        reviewer: req.user._id,
        status: 'submitted'
      });

      const pendingReviews = assignedApplications.length;

      data = {
        assignedApplications,
        completedReviews,
        pendingReviews
      };
    } else {
      // Applicant dashboard
      const myApplications = await Application.find({ applicant: req.user._id })
        .populate('grantCycle', 'name status')
        .sort({ createdAt: -1 });

      data = {
        myApplications
      };
    }

    res.json({
      status: 'success',
      data
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

// @route   GET /api/analytics/export
// @desc    Export applications data as CSV
// @access  Private (Admin)
router.get('/export', protect, authorize('admin'), async (req, res) => {
  try {
    const applications = await Application.find()
      .populate('applicant', 'name email organization')
      .populate('grantCycle', 'name')
      .lean();

    // Convert to CSV format
    const headers = ['Title', 'Applicant', 'Email', 'Organization', 'Grant Cycle', 'Budget Requested', 'Status', 'Average Score', 'Submitted At'];
    const rows = applications.map(app => [
      app.title,
      app.applicant?.name || '',
      app.applicant?.email || '',
      app.applicant?.organization || '',
      app.grantCycle?.name || '',
      app.budgetRequested,
      app.status,
      app.averageScore || 0,
      app.submittedAt ? new Date(app.submittedAt).toISOString() : ''
    ]);

    const csv = [headers, ...rows].map(row => row.join(',')).join('\n');

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename=applications_export.csv');
    res.send(csv);
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error',
      message: error.message 
    });
  }
});

module.exports = router;
