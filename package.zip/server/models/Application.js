const mongoose = require('mongoose');

const applicationSchema = new mongoose.Schema({
  applicant: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  grantCycle: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'GrantCycle',
    required: true
  },
  title: {
    type: String,
    required: [true, 'Project title is required'],
    trim: true,
    maxlength: [200, 'Title cannot exceed 200 characters']
  },
  summary: {
    type: String,
    required: [true, 'Project summary is required'],
    maxlength: [500, 'Summary cannot exceed 500 characters']
  },
  fullProposal: {
    type: String,
    required: [true, 'Full proposal is required'],
    maxlength: 10000
  },
  budgetRequested: {
    type: Number,
    required: [true, 'Budget requested is required'],
    min: [0, 'Budget cannot be negative']
  },
  budgetBreakdown: {
    personnel: Number,
    equipment: Number,
    services: Number,
    other: Number,
    description: String
  },
  timeline: {
    type: String,
    maxlength: 2000
  },
  teamMembers: [{
    name: String,
    role: String,
    experience: String
  }],
  status: {
    type: String,
    enum: ['draft', 'submitted', 'under_review', 'approved', 'rejected', 'revision_requested'],
    default: 'draft'
  },
  reviewers: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  reviews: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Review'
  }],
  scores: {
    technicalFeasibility: Number,
    impact: Number,
    innovation: Number,
    sustainability: Number,
    teamCapability: Number
  },
  averageScore: {
    type: Number,
    default: 0
  },
  totalScore: {
    type: Number,
    default: 0
  },
  documents: [{
    name: String,
    url: String,
    uploadedAt: {
      type: Date,
      default: Date.now
    }
  }],
  revisionRequests: [{
    message: String,
    requestedAt: {
      type: Date,
      default: Date.now
    },
    respondedAt: Date,
    response: String
  }],
  submittedAt: Date,
  reviewedAt: Date,
  decisionAt: Date,
  decisionBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  notes: {
    type: String,
    maxlength: 2000
  }
}, {
  timestamps: true
});

// Index for efficient queries
applicationSchema.index({ applicant: 1, grantCycle: 1 });
applicationSchema.index({ status: 1 });
applicationSchema.index({ grantCycle: 1, status: 1 });

// Calculate average score before saving
applicationSchema.pre('save', function(next) {
  if (this.scores) {
    const scoreValues = Object.values(this.scores).filter(v => typeof v === 'number');
    if (scoreValues.length > 0) {
      this.totalScore = scoreValues.reduce((a, b) => a + b, 0);
      this.averageScore = this.totalScore / scoreValues.length;
    }
  }
  next();
});

module.exports = mongoose.model('Application', applicationSchema);
