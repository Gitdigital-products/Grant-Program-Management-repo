const mongoose = require('mongoose');

const grantCycleSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Grant cycle name is required'],
    trim: true,
    maxlength: [100, 'Name cannot exceed 100 characters']
  },
  description: {
    type: String,
    maxlength: [1000, 'Description cannot exceed 1000 characters']
  },
  budgetTotal: {
    type: Number,
    required: [true, 'Total budget is required'],
    min: [0, 'Budget cannot be negative']
  },
  budgetAllocated: {
    type: Number,
    default: 0
  },
  maxGrantAmount: {
    type: Number,
    required: true,
    min: [0, 'Maximum grant amount cannot be negative']
  },
  minGrantAmount: {
    type: Number,
    required: true,
    min: [0, 'Minimum grant amount cannot be negative']
  },
  startDate: {
    type: Date,
    required: [true, 'Start date is required']
  },
  endDate: {
    type: Date,
    required: [true, 'End date is required']
  },
  applicationDeadline: {
    type: Date,
    required: [true, 'Application deadline is required']
  },
  reviewDeadline: {
    type: Date,
    required: [true, 'Review deadline is required']
  },
  status: {
    type: String,
    enum: ['draft', 'active', 'reviewing', 'closed', 'completed'],
    default: 'draft'
  },
  rubric: {
    criteria: [{
      name: {
        type: String,
        required: true
      },
      description: String,
      weight: {
        type: Number,
        required: true,
        min: 0,
        max: 100
      },
      maxScore: {
        type: Number,
        default: 10
      }
    }],
    passingScore: {
      type: Number,
      default: 60
    }
  },
  requiredDocuments: [{
    name: {
      type: String,
      required: true
    },
    description: String,
    required: {
      type: Boolean,
      default: true
    }
  }],
  guidelines: {
    type: String,
    maxlength: 5000
  },
  isPublic: {
    type: Boolean,
    default: true
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }
}, {
  timestamps: true
});

// Validate dates
grantCycleSchema.pre('save', function(next) {
  if (this.applicationDeadline > this.endDate) {
    next(new Error('Application deadline must be before end date'));
  }
  if (this.reviewDeadline < this.endDate) {
    next(new Error('Review deadline must be on or before end date'));
  }
  next();
});

// Virtual for checking if cycle is currently accepting applications
grantCycleSchema.virtual('isAcceptingApplications').get(function() {
  const now = new Date();
  return this.status === 'active' && 
         now >= this.startDate && 
         now <= this.applicationDeadline;
});

module.exports = mongoose.model('GrantCycle', grantCycleSchema);
