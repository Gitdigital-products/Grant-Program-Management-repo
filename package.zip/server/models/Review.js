const mongoose = require('mongoose');

const reviewSchema = new mongoose.Schema({
  reviewer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  application: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Application',
    required: true
  },
  scores: {
    technicalFeasibility: {
      type: Number,
      min: 0,
      max: 10
    },
    impact: {
      type: Number,
      min: 0,
      max: 10
    },
    innovation: {
      type: Number,
      min: 0,
      max: 10
    },
    sustainability: {
      type: Number,
      min: 0,
      max: 10
    },
    teamCapability: {
      type: Number,
      min: 0,
      max: 10
    }
  },
  totalScore: {
    type: Number,
    default: 0
  },
  comments: {
    type: String,
    maxlength: 3000,
    required: [true, 'Review comments are required']
  },
  strengths: [{
    type: String
  }],
  weaknesses: [{
    type: String
  }],
  questions: [{
    type: String
  }],
  recommendation: {
    type: String,
    enum: ['strong_approve', 'approve', 'neutral', 'reject', 'strong_reject'],
    required: [true, 'Recommendation is required']
  },
  recommendationReason: {
    type: String,
    maxlength: 1000
  },
  status: {
    type: String,
    enum: ['pending', 'submitted', 'revised'],
    default: 'pending'
  },
  submittedAt: Date,
  revisedAt: Date
}, {
  timestamps: true
});

// Compound index to ensure one review per reviewer per application
reviewSchema.index({ reviewer: 1, application: 1 }, { unique: true });

// Calculate total score before saving
reviewSchema.pre('save', function(next) {
  if (this.scores) {
    const scoreValues = Object.values(this.scores).filter(v => typeof v === 'number');
    if (scoreValues.length > 0) {
      this.totalScore = scoreValues.reduce((a, b) => a + b, 0);
    }
  }
  next();
});

module.exports = mongoose.model('Review', reviewSchema);
