import json
import sys
from collections import defaultdict
from datetime import datetime

def analyze_grants(data_file):
    """
    Analytics engine for Grant Program Management
    Analyzes application data and generates insights
    """
    
    # Load data from JSON file
    with open(data_file, 'r') as f:
        data = json.load(f)
    
    applications = data.get('applications', [])
    grant_cycles = data.get('grantCycles', [])
    
    # Create cycle lookup
    cycle_lookup = {str(c['_id']): c['name'] for c in grant_cycles}
    
    # Basic Statistics
    total_applications = len(applications)
    approved = sum(1 for a in applications if a.get('status') == 'approved')
    rejected = sum(1 for a in applications if a.get('status') == 'rejected')
    pending = sum(1 for a in applications if a.get('status') in ['submitted', 'under_review'])
    draft = sum(1 for a in applications if a.get('status') == 'draft')
    
    # Budget Analysis
    budgets = [a.get('budgetRequested', 0) for a in applications if a.get('budgetRequested')]
    total_budget_requested = sum(budgets)
    avg_budget = total_budget_requested / len(budgets) if budgets else 0
    max_budget = max(budgets) if budgets else 0
    min_budget = min(budgets) if budgets else 0
    
    # Approved budget analysis
    approved_budgets = [a.get('budgetRequested', 0) for a in applications if a.get('status') == 'approved']
    total_approved_budget = sum(approved_budgets)
    avg_approved_budget = total_approved_budget / len(approved_budgets) if approved_budgets else 0
    
    # Score Analysis
    scores = [a.get('averageScore', 0) for a in applications if a.get('averageScore', 0) > 0]
    avg_score = sum(scores) / len(scores) if scores else 0
    max_score = max(scores) if scores else 0
    min_score = min(scores) if scores else 0
    
    # Application by Cycle
    by_cycle = defaultdict(lambda: {'total': 0, 'approved': 0, 'rejected': 0, 'pending': 0, 'budget': 0})
    for app in applications:
        cycle_id = app.get('grantCycle')
        cycle_name = cycle_lookup.get(str(cycle_id), 'Unknown')
        by_cycle[cycle_name]['total'] += 1
        by_cycle[cycle_name]['budget'] += app.get('budgetRequested', 0)
        
        status = app.get('status')
        if status == 'approved':
            by_cycle[cycle_name]['approved'] += 1
        elif status == 'rejected':
            by_cycle[cycle_name]['rejected'] += 1
        elif status in ['submitted', 'under_review']:
            by_cycle[cycle_name]['pending'] += 1
    
    # Calculate approval rates by cycle
    for cycle_name in by_cycle:
        total = by_cycle[cycle_name]['total']
        approved = by_cycle[cycle_name]['approved']
        by_cycle[cycle_name]['approval_rate'] = (approved / total * 100) if total > 0 else 0
    
    # Budget vs Approval Correlation
    budget_ranges = {
        '0-5000': {'min': 0, 'max': 5000, 'approved': 0, 'total': 0},
        '5001-10000': {'min': 5001, 'max': 10000, 'approved': 0, 'total': 0},
        '10001-25000': {'min': 10001, 'max': 25000, 'approved': 0, 'total': 0},
        '25001-50000': {'min': 25001, 'max': 50000, 'approved': 0, 'total': 0},
        '50001+': {'min': 50001, 'max': float('inf'), 'approved': 0, 'total': 0}
    }
    
    for app in applications:
        budget = app.get('budgetRequested', 0)
        for range_name, range_data in budget_ranges.items():
            if range_data['min'] <= budget <= range_data['max']:
                range_data['total'] += 1
                if app.get('status') == 'approved':
                    range_data['approved'] += 1
                break
    
    # Calculate approval rates by budget range
    budget_analysis = {}
    for range_name, range_data in budget_ranges.items():
        total = range_data['total']
        approved = range_data['approved']
        budget_analysis[range_name] = {
            'total': total,
            'approved': approved,
            'approval_rate': (approved / total * 100) if total > 0 else 0
        }
    
    # Score distribution
    score_ranges = {
        '0-2': {'min': 0, 'max': 2, 'count': 0},
        '2-4': {'min': 2, 'max': 4, 'count': 0},
        '4-6': {'min': 4, 'max': 6, 'count': 0},
        '6-8': {'min': 6, 'max': 8, 'count': 0},
        '8-10': {'min': 8, 'max': 10, 'count': 0}
    }
    
    for score in scores:
        for range_name, range_data in score_ranges.items():
            if range_data['min'] <= score < range_data['max']:
                range_data['count'] += 1
                break
    
    # Submission trends (by month)
    submission_trends = defaultdict(int)
    for app in applications:
        if app.get('submittedAt'):
            try:
                date = datetime.fromisoformat(app['submittedAt'].replace('Z', '+00:00'))
                month_key = date.strftime('%Y-%m')
                submission_trends[month_key] += 1
            except:
                pass
    
    # Compile results
    results = {
        'summary': {
            'total_applications': total_applications,
            'approved': approved,
            'rejected': rejected,
            'pending': pending,
            'draft': draft,
            'approval_rate': (approved / total_applications * 100) if total_applications > 0 else 0,
            'rejection_rate': (rejected / total_applications * 100) if total_applications > 0 else 0
        },
        'budget_analysis': {
            'total_requested': total_budget_requested,
            'average_requested': round(avg_budget, 2),
            'max_requested': max_budget,
            'min_requested': min_budget,
            'total_approved': total_approved_budget,
            'average_approved': round(avg_approved_budget, 2)
        },
        'score_analysis': {
            'average_score': round(avg_score, 2),
            'max_score': max_score,
            'min_score': min_score,
            'distribution': {k: v['count'] for k, v in score_ranges.items()}
        },
        'by_cycle': dict(by_cycle),
        'budget_ranges': budget_analysis,
        'submission_trends': dict(submission_trends),
        'generated_at': datetime.now().isoformat()
    }
    
    return results


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(json.dumps({'error': 'Please provide data file path'}))
        sys.exit(1)
    
    try:
        results = analyze_grants(sys.argv[1])
        print(json.dumps(results, indent=2))
    except Exception as e:
        print(json.dumps({'error': str(e)}))
        sys.exit(1)
