const { validationResult, body, param, query } = require('express-validator');
const mongoose = require('mongoose');

// Middleware to check validation results
const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      status: 'error',
      message: 'Validation failed',
      errors: errors.array()
    });
  }
  next();
};

// Validation rules
const authValidation = {
  register: [
    body('name')
      .trim()
      .notEmpty()
      .withMessage('Name is required')
      .isLength({ max: 100 })
      .withMessage('Name cannot exceed 100 characters'),
    body('email')
      .isEmail()
      .withMessage('Please enter a valid email')
      .normalizeEmail(),
    body('password')
      .isLength({ min: 6 })
      .withMessage('Password must be at least 6 characters'),
    body('role')
      .optional()
      .isIn(['admin', 'reviewer', 'applicant'])
      .withMessage('Invalid role'),
    validate
  ],
  login: [
    body('email')
      .isEmail()
      .withMessage('Please enter a valid email')
      .normalizeEmail(),
    body('password')
      .notEmpty()
      .withMessage('Password is required'),
    validate
  ]
};

const applicationValidation = {
  create: [
    body('grantCycle')
      .custom(value => mongoose.Types.ObjectId.isValid(value))
      .withMessage('Invalid grant cycle ID'),
    body('title')
      .trim()
      .notEmpty()
      .withMessage('Project title is required')
      .isLength({ max: 200 })
      .withMessage('Title cannot exceed 200 characters'),
    body('summary')
      .trim()
      .notEmpty()
      .withMessage('Project summary is required')
      .isLength({ max: 500 })
      .withMessage('Summary cannot exceed 500 characters'),
    body('fullProposal')
      .trim()
      .notEmpty()
      .withMessage('Full proposal is required')
      .isLength({ max: 10000 })
      .withMessage('Proposal cannot exceed 10000 characters'),
    body('budgetRequested')
      .isNumeric()
      .withMessage('Budget must be a number')
      .custom(value => value > 0)
      .withMessage('Budget must be greater than 0'),
    validate
  ],
  update: [
    body('title')
      .optional()
      .trim()
      .isLength({ max: 200 })
      .withMessage('Title cannot exceed 200 characters'),
    body('summary')
      .optional()
      .trim()
      .isLength({ max: 500 })
      .withMessage('Summary cannot exceed 500 characters'),
    body('budgetRequested')
      .optional()
      .isNumeric()
      .withMessage('Budget must be a number'),
    validate
  ]
};

const reviewValidation = {
  create: [
    body('application')
      .custom(value => mongoose.Types.ObjectId.isValid(value))
      .withMessage('Invalid application ID'),
    body('scores.technicalFeasibility')
      .isNumeric()
      .withMessage('Technical feasibility score is required')
      .isFloat({ min: 0, max: 10 })
      .withMessage('Score must be between 0 and 10'),
    body('scores.impact')
      .isNumeric()
      .withMessage('Impact score is required')
      .isFloat({ min: 0, max: 10 })
      .withMessage('Score must be between 0 and 10'),
    body('scores.innovation')
      .isNumeric()
      .withMessage('Innovation score is required')
      .isFloat({ min: 0, max: 10 })
      .withMessage('Score must be between 0 and 10'),
    body('scores.sustainability')
      .isNumeric()
      .withMessage('Sustainability score is required')
      .isFloat({ min: 0, max: 10 })
      .withMessage('Score must be between 0 and 10'),
    body('scores.teamCapability')
      .isNumeric()
      .withMessage('Team capability score is required')
      .isFloat({ min: 0, max: 10 })
      .withMessage('Score must be between 0 and 10'),
    body('comments')
      .trim()
      .notEmpty()
      .withMessage('Review comments are required')
      .isLength({ max: 3000 })
      .withMessage('Comments cannot exceed 3000 characters'),
    body('recommendation')
      .isIn(['strong_approve', 'approve', 'neutral', 'reject', 'strong_reject'])
      .withMessage('Invalid recommendation'),
    validate
  ]
};

const grantCycleValidation = {
  create: [
    body('name')
      .trim()
      .notEmpty()
      .withMessage('Cycle name is required')
      .isLength({ max: 100 })
      .withMessage('Name cannot exceed 100 characters'),
    body('budgetTotal')
      .isNumeric()
      .withMessage('Total budget is required')
      .custom(value => value > 0)
      .withMessage('Budget must be greater than 0'),
    body('maxGrantAmount')
      .isNumeric()
      .withMessage('Maximum grant amount is required')
      .custom(value => value > 0)
      .withMessage('Maximum grant amount must be greater than 0'),
    body('minGrantAmount')
      .isNumeric()
      .withMessage('Minimum grant amount is required')
      .custom(value => value > 0)
      .withMessage('Minimum grant amount must be greater than 0'),
    body('startDate')
      .isISO8601()
      .withMessage('Start date is required'),
    body('endDate')
      .isISO8601()
      .withMessage('End date is required'),
    body('applicationDeadline')
      .isISO8601()
      .withMessage('Application deadline is required'),
    body('reviewDeadline')
      .isISO8601()
      .withMessage('Review deadline is required'),
    validate
  ]
};

const idValidation = [
  param('id')
    .custom(value => mongoose.Types.ObjectId.isValid(value))
    .withMessage('Invalid ID'),
  validate
];

module.exports = {
  validate,
  authValidation,
  applicationValidation,
  reviewValidation,
  grantCycleValidation,
  idValidation
};
